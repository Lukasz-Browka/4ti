const slider = document.querySelector('input')
const p = document.querySelector('p')

const showNumer = () => {
    p.textContent = slider.value
}

slider.addEventListener('mousemove',showNumer)